package cadastrobd;

public class CadastroBD {
    
    public static void main(String[] args) {
        MenuApp menu = new MenuApp();
        menu.exibirMenu();
    }
    
}
